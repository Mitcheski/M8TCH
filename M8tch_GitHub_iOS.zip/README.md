# M8tch (iOS • SwiftUI) — GitHub Build Ready

This repo uses **XcodeGen** to generate the Xcode project and a **GitHub Actions** workflow to build the iOS app for Simulator.

## Local setup
1. Install Xcode (15+).
2. Install XcodeGen: `brew install xcodegen`
3. Generate the project: `xcodegen generate`
4. Open `M8tch.xcodeproj` and Run on an iPhone simulator.

## CI (GitHub Actions)
- Push this repo to GitHub.
- CI will run on every push to `main`, generating the project and building it for an iPhone Simulator (no codesigning required).

## Structure
```
M8tch/
  Sources/          // SwiftUI app code (MVVM)
  Resources/        // Info.plist
  Assets.xcassets/  // Images/colors (empty placeholder)
.github/workflows/  // CI pipeline
project.yml         // XcodeGen spec
```

## Notes
- Networking is mocked with `MockApiClient` so the app is demo-able immediately.
- Swap in a real backend later by implementing `ApiClient` and injecting it via `AppState`.
