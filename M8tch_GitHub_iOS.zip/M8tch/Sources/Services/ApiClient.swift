import Foundation

protocol ApiClient {
    func submitProfile(user: User, prefs: Preferences) async throws
    func fetchMatchOffer() async throws -> MatchOffer?
    func respondToOffer(offerId: UUID, interested: Bool) async throws
    func confirmReservation(offerId: UUID, date: Date, venue: Venue) async throws -> Reservation
    func submitFeedback(matchId: UUID, feedback: FeedbackPayload) async throws
}

enum APIError: Error { case notFound, network, invalid }
