import Foundation

actor MockApiClient: ApiClient {
    private var storedUser: User?
    private var storedPrefs: Preferences?
    private var pendingOffer: MatchOffer?

    func submitProfile(user: User, prefs: Preferences) async throws {
        storedUser = user
        storedPrefs = prefs
        let candidate = Candidate(id: UUID(), name: "Alex (they/them)", age: 29, city: "Toronto",
                                  tags: ["indie film","cafés"], distanceKm: 4,
                                  rationaleAI: "Shared weekend availability, distance < 5km",
                                  rationaleHuman: "Values-aligned, similar coffee obsessions")
        let venues = [
            Venue(id: UUID(), name: "Lavender Café", priceBand: "$$", distanceKm: 2, accessibilityNotes: "Step-free entrance"),
            Venue(id: UUID(), name: "Common Grounds", priceBand: "$", distanceKm: 3, accessibilityNotes: "Gender-neutral restroom"),
            Venue(id: UUID(), name: "Moonlight Roasters", priceBand: "$$", distanceKm: 5, accessibilityNotes: "Quiet seating")
        ]
        let now = Date()
        let slots = [1,2,3].map { Calendar.current.date(byAdding: .day, value: $0, to: now)! }
        pendingOffer = MatchOffer(id: UUID(), candidate: candidate, proposedSlots: slots, proposedVenues: venues)
    }

    func fetchMatchOffer() async throws -> MatchOffer? { pendingOffer }

    func respondToOffer(offerId: UUID, interested: Bool) async throws {
        if !interested { pendingOffer = nil }
    }

    func confirmReservation(offerId: UUID, date: Date, venue: Venue) async throws -> Reservation {
        guard let offer = pendingOffer, offer.id == offerId else { throw APIError.notFound }
        let res = Reservation(id: UUID(), venue: venue, startAt: date, endAt: date.addingTimeInterval(3600), status: "confirmed")
        pendingOffer = nil
        return res
    }

    func submitFeedback(matchId: UUID, feedback: FeedbackPayload) async throws { }
}
