import Foundation

@MainActor
final class SchedulingViewModel: ObservableObject {
    @Published var selectedDate: Date?
    @Published var selectedVenue: Venue?
    @Published var confirmed: Reservation?
    let api: ApiClient
    let offer: MatchOffer

    init(api: ApiClient, offer: MatchOffer) {
        self.api = api
        self.offer = offer
    }

    func confirm() async {
        guard let d = selectedDate, let v = selectedVenue else { return }
        do { confirmed = try await api.confirmReservation(offerId: offer.id, date: d, venue: v) } catch { }
    }
}
