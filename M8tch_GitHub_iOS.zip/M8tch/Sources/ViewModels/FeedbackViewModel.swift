import Foundation

@MainActor
final class FeedbackViewModel: ObservableObject {
    @Published var chemistry: Int = 3
    @Published var comfort: Bool = true
    @Published var wouldMeetAgain: Bool = true
    @Published var notes: String = ""

    let api: ApiClient
    let matchId: UUID

    init(api: ApiClient, matchId: UUID) {
        self.api = api
        self.matchId = matchId
    }

    func submit() async {
        let payload = FeedbackPayload(chemistry: chemistry, comfort: comfort, wouldMeetAgain: wouldMeetAgain, notes: notes)
        try? await api.submitFeedback(matchId: matchId, feedback: payload)
    }
}
