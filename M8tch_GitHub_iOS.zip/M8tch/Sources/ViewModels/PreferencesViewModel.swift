import Foundation

final class PreferencesViewModel: ObservableObject {
    @Published var intent: [String] = []
    @Published var dealbreakers: [String] = []
    @Published var distanceKm: Int = 10
    @Published var ageMin: Int = 21
    @Published var ageMax: Int = 45
    @Published var budgetBand: String = "$$"

    func buildPrefs() -> Preferences {
        Preferences(intent: intent, dealbreakers: dealbreakers, distanceKm: distanceKm, ageMin: ageMin, ageMax: ageMax, budgetBand: budgetBand, availability: [], languages: [], accessibility: [])
    }
}
