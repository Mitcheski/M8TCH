import Foundation

@MainActor
final class MatchViewModel: ObservableObject {
    @Published var loading = false
    @Published var offer: MatchOffer?
    let api: ApiClient

    init(api: ApiClient) { self.api = api }

    func pollOffer() async {
        loading = true
        defer { loading = false }
        do { offer = try await api.fetchMatchOffer() } catch { offer = nil }
    }

    func respond(interested: Bool) async {
        guard let offer else { return }
        try? await api.respondToOffer(offerId: offer.id, interested: interested)
        if !interested { self.offer = nil }
    }
}
