import Foundation

final class AppState: ObservableObject {
    @Published var onboardingComplete = false
    @Published var hasSubmittedPrefs = false
    @Published var activeOffer: MatchOffer?
    @Published var lastReservation: Reservation?
    let api: ApiClient

    init(api: ApiClient = MockApiClient()) {
        self.api = api
    }
}
