import Foundation

final class OnboardingViewModel: ObservableObject {
    @Published var displayName = ""
    @Published var pronouns = ""
    @Published var orientation: [String] = []
    @Published var age: Int = 25
    @Published var city: String = "Toronto"

    func buildUser() -> User {
        User(id: UUID(),
             displayName: displayName.isEmpty ? "You" : displayName,
             pronouns: pronouns,
             orientation: orientation,
             age: age,
             city: city,
             location: nil)
    }
}
