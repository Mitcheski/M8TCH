import Foundation
import CoreLocation

struct User: Identifiable, Codable, Equatable {
    let id: UUID
    var displayName: String
    var pronouns: String
    var orientation: [String]
    var age: Int
    var city: String
    var location: CLLocationCoordinate2D?
    var photos: [URL] = []
}

struct Preferences: Codable, Equatable {
    var intent: [String] = []
    var dealbreakers: [String] = []
    var distanceKm: Int = 15
    var ageMin: Int = 18
    var ageMax: Int = 120
    var budgetBand: String = "$$"
    var availability: [AvailabilityBlock] = []
    var languages: [String] = []
    var accessibility: [String] = []
}

struct AvailabilityBlock: Codable, Equatable, Identifiable {
    var id = UUID()
    var weekday: Int
    var start: String
    var end: String
}

struct Candidate: Identifiable, Codable, Equatable {
    let id: UUID
    var name: String
    var age: Int
    var city: String
    var tags: [String]
    var distanceKm: Int
    var rationaleAI: String
    var rationaleHuman: String
}

struct Venue: Identifiable, Codable, Equatable {
    let id: UUID
    var name: String
    var priceBand: String
    var distanceKm: Int
    var accessibilityNotes: String
}

struct MatchOffer: Identifiable, Codable, Equatable {
    let id: UUID
    var candidate: Candidate
    var proposedSlots: [Date]
    var proposedVenues: [Venue]
}

struct Reservation: Identifiable, Codable, Equatable {
    let id: UUID
    var venue: Venue
    var startAt: Date
    var endAt: Date
    var status: String
}

struct FeedbackPayload: Codable {
    var chemistry: Int
    var comfort: Bool
    var wouldMeetAgain: Bool
    var notes: String
}
