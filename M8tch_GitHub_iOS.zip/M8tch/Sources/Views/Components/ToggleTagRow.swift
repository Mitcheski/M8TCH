import SwiftUI

struct ToggleTagRow: View {
    let options: [String]
    @Binding var selection: [String]

    var body: some View {
        FlowLayout {
            ForEach(options, id: \.self) { opt in
                let isOn = selection.contains(opt)
                Text(opt)
                    .padding(.vertical, 8).padding(.horizontal, 12)
                    .background(isOn ? Color.accentColor.opacity(0.2) : Color.secondary.opacity(0.1))
                    .clipShape(Capsule())
                    .overlay(Capsule().stroke(isOn ? Color.accentColor : Color.secondary.opacity(0.3)))
                    .onTapGesture {
                        if isOn { selection.removeAll { $0 == opt } } else { selection.append(opt) }
                    }
            }
        }
    }
}

struct FlowLayout<Content: View>: View {
    @ViewBuilder var content: Content
    @State private var totalHeight: CGFloat = .zero

    var body: some View {
        GeometryReader { geo in generateContent(in: geo) }
            .frame(height: totalHeight)
    }

    func generateContent(in g: GeometryProxy) -> some View {
        var width = CGFloat.zero
        var height = CGFloat.zero

        return ZStack(alignment: .topLeading) {
            content
                .alignmentGuide(.leading) { d in
                    if abs(width - d.width) > g.size.width {
                        width = 0; height -= d.height
                    }
                    let result = width
                    width -= d.width
                    return result
                }
                .alignmentGuide(.top) { _ in height }
        }
        .background(viewHeightReader($totalHeight))
    }

    func viewHeightReader(_ binding: Binding<CGFloat>) -> some View {
        GeometryReader { geometry -> Color in
            DispatchQueue.main.async { binding.wrappedValue = geometry.size.height }
            return .clear
        }
    }
}
