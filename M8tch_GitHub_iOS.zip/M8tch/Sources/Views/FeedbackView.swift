import SwiftUI

struct FeedbackView: View {
    @StateObject var vm: FeedbackViewModel
    init(matchId: UUID) { _vm = StateObject(wrappedValue: FeedbackViewModel(api: MockApiClient(), matchId: matchId)) }

    var body: some View {
        Form {
            Stepper("Chemistry: \(vm.chemistry)", value: $vm.chemistry, in: 1...5)
            Toggle("Felt comfortable & safe", isOn: $vm.comfort)
            Toggle("Would meet again", isOn: $vm.wouldMeetAgain)
            TextField("Notes (optional)", text: $vm.notes, axis: .vertical)
            Button("Submit Feedback") { Task { await vm.submit() } }.buttonStyle(.borderedProminent)
        }
        .navigationTitle("How did it go?")
    }
}
