import SwiftUI

struct MatchOfferView: View {
    @EnvironmentObject var app: AppState
    @StateObject var vm = MatchViewModel(api: MockApiClient())
    let offer: MatchOffer

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(offer.candidate.name).font(.title2).bold()
            Text("\(offer.candidate.age) • \(offer.candidate.city) • ~\(offer.candidate.distanceKm)km").foregroundColor(.secondary)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack { ForEach(offer.candidate.tags, id: \.self) { Tag($0) } }
            }
            Text("AI: \(offer.candidate.rationaleAI)").font(.subheadline)
            Text("Matchmaker: \(offer.candidate.rationaleHuman)").font(.subheadline)
            HStack {
                Button("Pass") { Task { await vm.respond(interested: false); app.activeOffer = nil } }
                Spacer()
                NavigationLink("Interested") { SchedulingView(offer: offer) }
                    .buttonStyle(.borderedProminent)
            }.padding(.top, 12)
        }
        .padding()
        .navigationTitle("Curated Match")
    }
}

struct Tag: View {
    let text: String
    init(_ t: String) { self.text = t }
    var body: some View {
        Text(text).padding(.vertical, 6).padding(.horizontal, 10)
            .background(Color.accentColor.opacity(0.15))
            .clipShape(Capsule())
    }
}
