import SwiftUI

struct SchedulingView: View {
    @EnvironmentObject var app: AppState
    @StateObject var vm: SchedulingViewModel
    let offer: MatchOffer

    init(offer: MatchOffer) {
        self.offer = offer
        _vm = StateObject(wrappedValue: SchedulingViewModel(api: MockApiClient(), offer: offer))
    }

    var body: some View {
        List {
            Section("Pick a time") {
                ForEach(offer.proposedSlots, id: \.self) { slot in
                    HStack {
                        Text(slot.formatted(date: .abbreviated, time: .shortened))
                        Spacer()
                        if vm.selectedDate == slot { Image(systemName: "checkmark.circle.fill") }
                    }
                    .contentShape(Rectangle())
                    .onTapGesture { vm.selectedDate = slot }
                }
            }
            Section("Pick a venue") {
                ForEach(offer.proposedVenues) { v in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(v.name).bold()
                            Text("\(v.priceBand) • ~\(v.distanceKm)km").font(.subheadline).foregroundColor(.secondary)
                        }
                        Spacer()
                        if vm.selectedVenue?.id == v.id { Image(systemName: "checkmark.circle.fill") }
                    }
                    .contentShape(Rectangle())
                    .onTapGesture { vm.selectedVenue = v }
                }
            }
            if let res = vm.confirmed {
                Section("Reservation") {
                    Text("Confirmed at \(res.venue.name) on \(res.startAt.formatted(date: .abbreviated, time: .shortened))")
                }
                NavigationLink("Leave feedback") { FeedbackView(matchId: res.id) }
            } else {
                Button("Confirm Reservation") { Task { await vm.confirm() } }
                    .buttonStyle(.borderedProminent)
            }
        }
        .navigationTitle("Schedule date")
    }
}
