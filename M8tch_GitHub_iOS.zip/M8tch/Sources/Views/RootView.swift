import SwiftUI

struct RootView: View {
    @EnvironmentObject var app: AppState
    var body: some View {
        if !app.onboardingComplete { OnboardingView() }
        else if app.activeOffer == nil { MatchProgressView() }
        else if let offer = app.activeOffer { MatchOfferView(offer: offer) }
    }
}
