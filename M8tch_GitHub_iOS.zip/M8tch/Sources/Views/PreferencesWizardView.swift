import SwiftUI

struct PreferencesWizardView: View {
    @EnvironmentObject var app: AppState
    @StateObject var vm = PreferencesViewModel()
    let user: User

    var body: some View {
        Form {
            Section("Intent") {
                ToggleTagRow(options: ["Long-term","Casual","Friends-first","Exploring"], selection: $vm.intent)
            }
            Section("Dealbreakers") {
                TextField("Comma-separated dealbreakers", text: Binding(
                    get: { vm.dealbreakers.joined(separator: ", ") },
                    set: { vm.dealbreakers = $0.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) } }
                ))
            }
            Section("Distance: \(vm.distanceKm) km") {
                Slider(value: Binding(get: { Double(vm.distanceKm) }, set: { vm.distanceKm = Int($0) }), in: 1...100)
            }
            Section("Age range") {
                HStack {
                    Stepper("Min: \(vm.ageMin)", value: $vm.ageMin, in: 18...120)
                    Stepper("Max: \(vm.ageMax)", value: $vm.ageMax, in: 18...120)
                }
            }
            Section("Budget") {
                Picker("Budget", selection: $vm.budgetBand) {
                    ForEach(["$","$$","$$$"], id: \.self) { Text($0) }
                }.pickerStyle(.segmented)
            }
            Button("Submit & Start Curation") {
                Task {
                    let prefs = vm.buildPrefs()
                    try? await app.api.submitProfile(user: user, prefs: prefs)
                    app.onboardingComplete = true
                }
            }
        }
        .navigationTitle("Preferences")
    }
}
