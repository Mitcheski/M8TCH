import SwiftUI

struct OnboardingView: View {
    @EnvironmentObject var app: AppState
    @StateObject var vm = OnboardingViewModel()

    var body: some View {
        Form {
            Section("Profile") {
                TextField("Display name", text: $vm.displayName)
                TextField("Pronouns", text: $vm.pronouns)
                Stepper("Age: \(vm.age)", value: $vm.age, in: 18...120)
                TextField("City", text: $vm.city)
            }
            Section("Orientation (comma-separated)") {
                TextField("e.g., gay, bi, queer", text: Binding(
                    get: { vm.orientation.joined(separator: ", ") },
                    set: { vm.orientation = $0.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) } }
                ))
            }
            NavigationLink("Next: Preferences") {
                PreferencesWizardView(user: vm.buildUser())
            }
        }
        .navigationTitle("Welcome to M8tch")
    }
}
