import SwiftUI

struct MatchProgressView: View {
    @EnvironmentObject var app: AppState
    @StateObject var vm = MatchViewModel(api: MockApiClient())

    var body: some View {
        VStack(spacing: 16) {
            ProgressView("We’re curating your match (≤48h)")
            Button("Check for Update") {
                Task { await vm.pollOffer(); app.activeOffer = vm.offer }
            }
            .buttonStyle(.borderedProminent)
            NavigationLink("Settings") { SettingsView() }
        }
        .padding()
        .navigationTitle("Curation in Progress")
        .onAppear { Task { await vm.pollOffer(); app.activeOffer = vm.offer } }
    }
}
