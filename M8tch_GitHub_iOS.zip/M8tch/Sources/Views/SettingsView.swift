import SwiftUI

struct SettingsView: View {
    var body: some View {
        Form {
            Section("Safety") {
                Toggle("Share trip with trusted contact", isOn: .constant(false))
                Button("Emergency: I need help") {}
                    .foregroundColor(.red)
            }
            Section("Account") {
                Button("Edit profile") {}
                Button("Sign out") {}
            }
        }
        .navigationTitle("Settings")
    }
}
