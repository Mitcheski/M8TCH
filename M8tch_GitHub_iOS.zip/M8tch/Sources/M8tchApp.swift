import SwiftUI

@main
struct M8tchApp: App {
    @StateObject var app = AppState()
    var body: some Scene {
        WindowGroup {
            NavigationStack {
                if !app.onboardingComplete {
                    OnboardingView()
                } else if app.activeOffer == nil {
                    MatchProgressView()
                } else {
                    if let offer = app.activeOffer {
                        MatchOfferView(offer: offer)
                    }
                }
            }
            .environmentObject(app)
        }
    }
}
